# Image Generation Prompts

## Logo
Prompt: `A minimalist, premium logo for a tea brand named 'Mistvale'. Clean typography with a small, elegant leaf and mist mark. White background.`

## Hero Banner
Prompt: `A premium, calm hero banner for a tea brand. A warm cup of tea on a wooden table, natural sunlight streaming in, soft shadows. Earthy tones, parchment and cream background. No text.`

## Products
*Note: Due to API rate limits, the last 4 products use copies of the generated images as placeholders.*

**p101 (Assam Breakfast Black Tea):**
Prompt: `Product photography of Assam Breakfast Black Tea. A premium tea package next to loose strong malty black CTC tea leaves. Cream and wood background, natural lighting, square framing, no text.`

**p102 (Darjeeling First Flush):**
Prompt: `Product photography of Darjeeling First Flush tea. A premium tea package next to delicate, floral spring harvest green-brown tea leaves. Cream and linen background, natural lighting, square framing, no text.`

**p103 (Kashmiri Kahwa):**
Prompt: `Product photography of Kashmiri Kahwa. A premium tea package next to green tea leaves mixed with saffron strands, cardamom, cinnamon, and almond flakes. Cream and wood background, natural lighting, square framing, no text.`

**p104 (Masala Chai Blend):**
Prompt: `Product photography of Masala Chai Blend. A premium tea package next to bold Assam leaves with ginger, cardamom, clove, and black pepper. Cream and wood background, natural lighting, square framing, no text.`

**p105 (Nilgiri Green Tea) [Rate limited - Restored original placeholder `p105.png`]:**
Prompt: `Product photography of Nilgiri Green Tea. A premium tea package next to smooth, grassy green tea leaves. Cream and wood background, natural lighting, square framing, no text.`

**p106 (Chamomile & Tulsi) [Rate limited - Restored original placeholder `p106.png`]:**
Prompt: `Product photography of Chamomile & Tulsi tea. A premium tea package next to a blend of chamomile flowers and holy basil (tulsi) leaves. Cream and linen background, natural lighting, square framing, no text.`

**p107 (Hibiscus Rose Infusion) [Rate limited - Restored original placeholder `p107.png`]:**
Prompt: `Product photography of Hibiscus Rose Infusion. A premium tea package next to tangy red hibiscus and dried rose petals. Cream and wood background, natural lighting, square framing, no text.`

**p108 (Tea Lover's Sampler) [Rate limited - Restored original placeholder `p108.png`]:**
Prompt: `Product photography of a Tea Lover's Sampler Gift Box. A premium wooden gift box containing six different tea varieties with a brewing guide. Cream and wood background, natural lighting, square framing, no text.`
